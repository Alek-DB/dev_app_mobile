package com.example.tp1;

import java.util.ArrayList;

public class Playlist {
    ArrayList<Track> music;     //Liste de toutes nos musiques

    public void setMusic(ArrayList<Track> music) {
        this.music = music;
    }
}
