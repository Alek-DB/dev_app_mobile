package com.example.tp1;

public interface ObservateurChangement {

    public void changement (Playlist p);
}
